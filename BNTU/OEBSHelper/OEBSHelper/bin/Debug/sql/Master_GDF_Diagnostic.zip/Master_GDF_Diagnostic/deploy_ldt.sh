{

echo "Enter APPS Password :"
stty -echo
read AppsPWD;
stty echo


#echo "Deploying Value Set..."
#echo "Deploying DFF..."


echo "AP Data Validation Analyzer..."
FNDLOAD apps/$AppsPWD 0 Y UPLOAD $FND_TOP/patch/115/import/afcpprog.lct ldt/APGDFVAL.ldt -WARNING=YES UPLOAD_MODE=REPLACE CUSTOM_MODE=FORCE 


echo "AP Single Transaction Data Validation Analyzer..."
FNDLOAD apps/$AppsPWD 0 Y UPLOAD $FND_TOP/patch/115/import/afcpprog.lct ldt/APGDFVAL_SINGLE.ldt -WARNING=YES UPLOAD_MODE=REPLACE CUSTOM_MODE=FORCE

} 2>&1 | tee deploy_ldt.log